import React,{Component} from 'react';

const Home = ()=>{
return (
    <div>
<h1>Inside The Home Page</h1> 
        </div>
)
}

export default Home;