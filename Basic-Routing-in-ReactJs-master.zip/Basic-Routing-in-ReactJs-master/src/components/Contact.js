import React,{Component} from 'react';

const Contact = ()=>{
return (
    <div>
<h1>Inside The Contact Page</h1> 
        </div>
)
}

export default Contact;