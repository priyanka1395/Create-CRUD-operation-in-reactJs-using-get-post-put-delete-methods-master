import React,{Component} from 'react';

const Error = ()=>{
return (
    <div>
<h1>Inside The Error Page</h1> 
        </div>
)
}

export default Error;